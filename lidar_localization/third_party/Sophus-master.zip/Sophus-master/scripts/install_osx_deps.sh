#!/bin/bash

set -x # echo on
set -e # exit on error
brew update
brew install ceres-solver fmt
